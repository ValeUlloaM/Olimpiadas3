let cuadros = [
  [0, 0, 0],
  [0, 0, 0],
  [0, 0, 0]
];

function setup() {
  createCanvas(800, 800);
  for(let i = 0; i < 3; i ++){
    for(let j = 0; j < 3; j ++){
      cuadros.push(new Casilla ((100 + i*200), (135 + i*200)));
    }
  }
}

function draw() {
  background(220);

  // Titulo
  fill(249, 59, 183);
  textSize(64)
  textAlign(CENTER);
  text('TRIQUI', 400, 73);
  textAlign(CORNER);

  for(let i = 0; i < 3; i ++){
    for(let j = 0; j < 3; j ++){
      cuadros[j][i].paint(); // no funciona
    }
  }

 
}