class Casilla {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.tam = 200;
    }

    paint() {
        fill(255)
        strokeWeight(4);
        rect(this.x, this.y, this.tam, this.tham);
    }
}